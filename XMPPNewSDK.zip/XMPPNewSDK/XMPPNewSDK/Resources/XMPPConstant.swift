//
//  XMPPConstant.swift
//  XMPPNewSDK
//
//  Created by ashish on 7/4/19.
//  Copyright © 2019 Capanicus. All rights reserved.
//

import Foundation
import UIKit

let xmppUserExt                             = "@chat.goidd.com"//"@beta.goidd.com"
let xmppRoomExt                             = "@muclight.chat.goidd.com"//"@conference.beta.goidd.com"
let _VIDEOFILE_EXTENSION                    = "mp4"
let _THUMBNAILDIRECTORY                     = "Thumbnail"
let CHATIMAGETHUMBNAILSIZE                  = CGSize(width:220.0, height:220.0)
let _IMAGE_FILE_MAX_SIZE                    = 20.0
let _IMAGEFILE_EXTENSION                    = "JPG"
